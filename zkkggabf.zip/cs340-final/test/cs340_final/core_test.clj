(ns cs340-final.core-test
  (:require [clojure.test :refer :all]
            [cs340-final.core :refer :all]))


;;   (apply-to-pairs * []) => []
;;   (apply-to-pairs + [1 2 3 4]) => [3 7]
;;   (apply-to-pairs * [1 2 3 4]) => [2 12]
;;   (apply-to-pairs vector [:a :b :c :d :e :f]) => 
;;     [[:a :b] [:c :d] [:e :f]]
(deftest apply-to-pairs-test
  (testing "apply-to-pairs"
    (is (= [] (apply-to-pairs * [])))
    (is (= [3 7] (apply-to-pairs + [1 2 3 4])))
    (is (= [2 12] (apply-to-pairs * [1 2 3 4])))
    (is (= [[:a :b] [:c :d] [:e :f]] (apply-to-pairs vector [:a :b :c :d :e :f])))
    ))


;;  (qpart [] 100) => [[] []]
;;  (qpart [1 14 8 10 4] 5) => [[1 4] [14 8 10]]
;;  (qpart [1 14 8 10 4] 9) => [[1 8 4] [14 10]]
;;  (qpart [1 14 8 10 4] 14) => [[1 8 10 4] [14]]
;;  (qpart [1 14 8 10 4] 15) => [[1 14 8 10 4] []]
;;  (qpart [1 14 8 10 4] 0) => [[] [1 14 8 10 4]]
;;  (qpart [1 14 8 10 4] 15) => [[1 14 8 10 4] []]
;;  (qpart [17 21 67 81 45 64 69 97 83 62 68 0 32 73 37] 47) =>
;;    [[17 21 45 0 32 37]
;;     [67 81 64 69 97 83 62 68 73]]
(deftest qpart-test
  (testing "qpart"
    (is (= [[] []] (qpart [] 100)))
    (is (= [[1 4] [14 8 10]] (qpart [1 14 8 10 4] 5)))
    (is (= [[1 8 4] [14 10]] (qpart [1 14 8 10 4] 9)))
    (is (= [[1 8 10 4] [14]] (qpart [1 14 8 10 4] 14)))
    (is (= [[1 14 8 10 4] []] (qpart [1 14 8 10 4] 15)))
    (is (= [[] [1 14 8 10 4]] (qpart [1 14 8 10 4] 0)))
    (is (= [[1 14 8 10 4] []] (qpart [1 14 8 10 4] 15)))
    (is (= [[17 21 45 0 32 37]
            [67 81 64 69 97 83 62 68 73]] (qpart [17 21 67 81 45 64 69 97 83 62 68 0 32 73 37] 47)))
    ))


;;   (my-eval 42) => 42
;;   (my-eval [:sub 11 3]) => 8
;;   (my-eval [:mul 4 5]) => 20
;;   (my-eval [:mul 4 [:add 3 8]]) => 44
;;   (my-eval [:div 9 3]) => 3
;;   (my-eval [:add [:mul 2 [:sub 6 4]] [:add [:div 9 3] 10]]) => 17
(deftest my-eval-test
  (testing "my-eval"
    (is (= 42 (my-eval 42)))
    (is (= 8 (my-eval [:sub 11 3])))
    (is (= 20 (my-eval [:mul 4 5])))
    (is (= 44 (my-eval [:mul 4 [:add 3 8]])))
    (is (= 3 (my-eval [:div 9 3])))
    (is (= 17 (my-eval [:add [:mul 2 [:sub 6 4]] [:add [:div 9 3] 10]])))
    ))
