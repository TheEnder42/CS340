# cs340-final

A Clojure library designed to ... well, that part is up to you.

## Usage

FIXME

## License

Copyright © 2017 FIXME

Distributed under the Eclipse Public License either version 1.0 or (at
your option) any later version.
