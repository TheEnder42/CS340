package edu.ycp.cs340.jsonparser;

public class JSONParser {
	private Lexer lexer;
	
	public JSONParser(Lexer lexer) {
		this.lexer = lexer;
	}
	
	public Node parseValue() {
		Node value = new Node(Symbol.VALUE);
		
		Token tok = lexer.peek();
		
		if (tok == null) {
			throw new ParserException("Unexpected end of input reading value");
		}
		
		if (tok.getSymbol() == Symbol.STRING_LITERAL) {
			// Value → StringLiteral
			value.getChildren().add(expect(Symbol.STRING_LITERAL));
		} else if (tok.getSymbol() == Symbol.INT_LITERAL) {
			// Value → IntLiteral
			value.getChildren().add(expect(Symbol.INT_LITERAL));
		} else if (tok.getSymbol() == Symbol.LBRACE) {
			// Value → Object
			value.getChildren().add(parseObject());
		} else if (tok.getSymbol() == Symbol.LBRACKET) {
			// Value → Array
			value.getChildren().add(parseArray());
		} else {
			throw new ParserException("Unexpected token looking for value: " + tok);
		}
		
		return value;
	}

	private Node parseObject() {
		Node object = new Node(Symbol.OBJECT);
		
		// Object → "{" OptFieldList "}"
		object.getChildren().add(expect(Symbol.LBRACE));
		object.getChildren().add(parseOptFieldList());
		object.getChildren().add(expect(Symbol.RBRACE));
		
		return object;
	}

	private Node parseOptFieldList() {
		Token tok = lexer.peek();
		Node fieldList = new Node(Symbol.OPT_FIELD_LIST);
		
		if (tok.getSymbol() == Symbol.RBRACE) {
			return fieldList;
		}
		else {
			fieldList.getChildren().add(parseFieldList());
			return fieldList;
		}
		
	}

	private Node parseFieldList() {
		
		Node field = new Node(Symbol.FIELD_LIST);
		
		field.getChildren().add(parseField());
		Token tok = lexer.peek();
		if(tok.getSymbol() == Symbol.COMMA){
			// FieldList -> Field ^ "," FieldList
			field.getChildren().add(expect(Symbol.COMMA));
			field.getChildren().add(parseFieldList());
		}
		return field;
	}

	private Node parseField() {
		Node value = new Node(Symbol.FIELD);

		// Field -> StringLiteral ":" Value
		value.getChildren().add(expect(Symbol.STRING_LITERAL));				
		value.getChildren().add(expect(Symbol.COLON));				
		value.getChildren().add(parseValue());
					
		return value;
	}

	private Node parseArray() {
		Node array = new Node(Symbol.ARRAY);
		
		// Array → "[" OptValueList "]"
		array.getChildren().add(expect(Symbol.LBRACKET));
		array.getChildren().add(parseOptValueList());
		array.getChildren().add(expect(Symbol.RBRACKET));
		
		return array;
	}

	private Node parseOptValueList() {
		Token tok = lexer.peek();
		Node valueList = new Node(Symbol.OPT_VALUE_LIST);
		
		if (tok == null) {
			return valueList;
		}
		else {
			valueList.getChildren().add(parseValueList());
			return valueList;
		}
	}

	private Node parseValueList() {
		Node value = new Node(Symbol.VALUE_LIST);
		
		// ValueList -> ^ Value
		// ValueList -> ^ Value "," ValueList
		
		value.getChildren().add(parseValue());
		
		// ValueList -> Value ^
		// ValueList -> Value ^ "," ValueList
		
		Token tok = lexer.peek();
		if(tok.getSymbol() == Symbol.COMMA){//TODO expect terminal symbol?
			// ValueList -> Value ^ "," ValueList
			value.getChildren().add(expect(Symbol.COMMA));
			value.getChildren().add(parseValueList());
		}
		return value;	
	}

	private Node expect(Symbol symbol) {
		Token tok = lexer.next();
		if (tok.getSymbol() != symbol) {
			throw new LexerException("Unexpected token " + tok + " (was expecting " + symbol + ")");
		}
		return new Node(tok);
	}
}
