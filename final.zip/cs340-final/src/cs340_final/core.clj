(ns cs340-final.core)

;; Question 10 [20 points].
;; This function takes two parameters: f, a function taking two
;; parameters, and s, a sequence with an even number of values.
;; It applies f to pairs of elements (first and second, third
;; and fourth, etc.), resulting the results in a sequence.
;;
;; Parameters:
;;   f - a function taking two parameters
;;   s - a sequence with an even number of elements
;;
;; Returns:
;;   a sequence containing the results of applying f to pairs
;;   of elements of s
;;
;; Hints/specifications:
;;   - use loop/recur to process the input sequence
;;   - a base case occurs when there are no more elements
;;   - the built-in first and second functions are useful
;;     for getting the first and second elements of a
;;     sequence
;;   - keep in mind that at each step, *TWO* elements
;;     of the input sequence should be consumed
;;     (i.e., if 'remaining' is the remaining elements,
;;     then each step should use both (first remaining)
;;     and (second remaining), and the recursion should be
;;     on (rest (rest remaining)))
;;
;; Examples:
;;   (apply-to-pairs * []) => []
;;   (apply-to-pairs + [1 2 3 4]) => [3 7]
;;   (apply-to-pairs * [1 2 3 4]) => [2 12]
;;   (apply-to-pairs vector [:a :b :c :d :e :f]) => 
;;     [[:a :b] [:c :d] [:e :f]]
;;
(defn apply-to-pairs [f s]
  (loop [accum [] ;I think here's the mistake, but im not sure how to declare this here
         allelse s]
    (if(< (count allelse) 2)
      accum
    (recur (conj accum (f (first allelse)(second allelse))) (rest(rest allelse)))
    )
  ) 
 )


;; Question 11 [15 points].
;; This function takes a vector of numeric values (v) and a
;; pivot value.  It should return a vector containing two
;; vectors, a left partition and a right partition.  The left
;; partition should contain all of the elements of v
;; less than the pivot value.  The right partition should
;; all of the elements of v greater than or equal to the
;; pivot value.
;;
;; Parameters:
;;    v - a vector of numeric values
;;    pivot - a numeric pivot value
;;
;; Returns:
;;   a vector containing the left partition and right partition
;;   as described above
;;
;; Hints/specifications:
;;   - use loop/recur to build the left and right partitions
;;   - the order of the elements in the left and right
;;     partitions should match the order of the elements in the
;;     original vector
;;   - there should be *two* accumulators (one for the left
;;     partition and one for the right partition)
;;
;; Examples:
;;  (qpart [] 100) => [[] []]
;;  (qpart [1 14 8 10 4] 5) => [[1 4] [14 8 10]]
;;  (qpart [1 14 8 10 4] 9) => [[1 8 4] [14 10]]
;;  (qpart [1 14 8 10 4] 14) => [[1 8 10 4] [14]]
;;  (qpart [1 14 8 10 4] 15) => [[1 14 8 10 4] []]
;;  (qpart [1 14 8 10 4] 0) => [[] [1 14 8 10 4]]
;;  (qpart [1 14 8 10 4] 15) => [[1 14 8 10 4] []]
;;  (qpart [17 21 67 81 45 64 69 97 83 62 68 0 32 73 37] 47) =>
;;    [[17 21 45 0 32 37]
;;     [67 81 64 69 97 83 62 68 73]]
;;
(defn qpart [v pivot]
  (loop [lowaccum []
         highaccum []
         allelse v]
    (if (= (count allelse) 0)
      [lowaccum highaccum]
      (recur
        (if (< (first allelse) pivot)
          (conj lowaccum (first allelse))
          lowaccum
        );end lowaccum
        (if (>= (first allelse) pivot)
          (conj highaccum (first allelse))
          highaccum
        );end highaccum
        (rest allelse);end decreasing queue
      );end recur statement
    );end recur if
  );end loop statement
);end function


;; Question 12 [15 points].
;; This function determines the value of expr, a numeric expression.
;; A numeric expression is one of the following:
;;
;;   - a number, in which case the value of the
;;     expression is simply the value of the number
;;   - a sequence containing an operator followed by two subexpressions,
;;     in which case the value of the expression is the result of
;;     applying the operator to the (recursively computed) values of
;;     the two subexpressions
;;
;; Valid operators are :add (addition), :sub (subtraction), :mul (multiplication),
;; and :div (division).
;;
;; Parameters:
;;   expr - a numeric expression (as described above)
;;
;; Returns:
;;   the result of evaluating the expression (as described above)
;;
;; Hints/specifications:
;;   - the number? predicate returns true if and only if the value
;;     to which it is applied is a number: e.g.,
;;        (number? 42)
;;     evaluates to true
;;   - if expr is a number, consider that to be a base case
;;   - your function does NOT need to be tail recursive
;;
;; Examples:
;;   (my-eval 42) => 42
;;   (my-eval [:sub 11 3]) => 8
;;   (my-eval [:mul 4 5]) => 20
;;   (my-eval [:mul 4 [:add 3 8]]) => 44
;;   (my-eval [:div 9 3]) => 3
;;   (my-eval [:add [:mul 2 [:sub 6 4]] [:add [:div 9 3] 10]]) => 17
;;
(defn my-eval [expr];will call full method recursion
  (if(number? expr)
    expr ;if number, return number
    (cond ;(:token expr)
      (= (get expr 0) :add) (+ (my-eval (get expr 1))(my-eval (get expr 2)))
      
      (= (get expr 0) :sub) (- (my-eval (get expr 1))(my-eval (get expr 2)))
      
      (= (get expr 0) :mul) (* (my-eval (get expr 1))(my-eval (get expr 2)))
      
      (= (get expr 0) :div) (/ (my-eval (get expr 1))(my-eval (get expr 2)))
      
      :else false
    );end cond
  );end if
);end function
